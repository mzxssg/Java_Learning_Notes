import Vue from 'vue'
import ElementUI from 'element-ui'
Vue.use(ElementUI)

import VueQriously from 'vue-qriously'
Vue.use(VueQriously)
